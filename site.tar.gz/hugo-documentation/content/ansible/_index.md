---
title: "Ansible"
date: 2018-01-28T22:01:36+01:00
anchor: "ansible"
weight: 120
---

```
yum install -y npm
npm install -g bocoup/learn-ansible
```

Cream un folder nou, pe care-l denumim ansible, unde vom lucra exercitiile.

Intram in folderul ansible si folosim comanda:
```
learn-ansible
```

Acum, daca intram pe localhost:8000, vom vedea toate exercitiile disponibile.

Am dat pe prima optiune, se creeaza un nou folder: your-development-server ce va contine:

exercise.json  overview.md  solution  Vagrantfile

