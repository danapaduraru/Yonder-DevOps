---
title: "Your Development Server"
date: 2018-01-28T22:01:36+01:00
anchor: "ansible-ex-1"
weight: 125
---

{{% block note %}}
**YOUR DEVELOPMENT SERVER**

This exercise contains a Vagrantfile which we will use to create a virtual machine running Ubuntu. 

You can get started using Vagrant with just a few commands:

To start the server, run vagrant up

To shut down the server (saving your changes), run vagrant halt

To destroy the server (discarding your changes), run vagrant destroy

To connect to your server, run vagrant ssh


**VAGRANT SSH**


Now that you understand how SSH works. What do you think is going on under the hood when you run vagrant ssh?

 As a hint, check out the .vagrant folder, it was created sibling to your Vagrantfile when you ran vagrant up.

See if you can connect to the vagrant machine using the ssh command directly. 

The IP address of your machine is specified in the Vagrantfile. Be sure to specify the right user!

**EXERCISE**

While connected to the VM, create a user for yourself:

```
sudo adduser --disabled-password <username>
```

Finally, using knowledge from previous exercises, configure an authorized_keys file for the new user using your own public key. 

Don't forget to set the right permission and ownership using chmod and chown!

You'll know you've succeeded when you can ssh to your VM without specifying a user or private key.

**LEARNING OBJECTIVES**

- How do you spin up a VM using Vagrant?

- How do you spin down a VM using Vagrant?

- How do you erase a VM created by vagrant?

- How does vagrant ssh work?

- How do you create a user on an Ubuntu machine?

- How do you configure password-less SSH access?

- How do you copy a file from your machine to a remote machine using SSH?

{{% /block %}}

Pe masina noastra virtuala, de pe userul root, vom crea un nou user.
``` 
adduser <numeuser>
```

Stergem parola userului nostru:
```
passwd -d <numeuser>
```

Facem o cheie publica pentru user.
Ne logam pe userul nostru:
```
su <numeuser>
```

Intram in folderul cu userul
``` 
cd /home/<numeuser>
```
Generam cheia:
``` 
ssh-keygen
```
Intram in folderul .ssh
```
cd .ssh
```
Cream fisierul authorized_keys cu continutul fisierului id_rsa.pub:
``` 
cp id_rsa.pub authorized_keys
```
Acum trebuie sa dam permisiuni si sa setam ownerul:
```
cd ..
chmod -R go= ~/.ssh
chown -R <numeuser>:<numeuser> ~/.ssh
```
Va trebui sa copiem continutul fisierului id_rsa (cel fara extensia .pub) din folderul .ssh
 
*Mergem pe masina noastra (Nu pe cea virtuala) si cream un fisier id_rsa
```
cd /home/<userulnostru>
touch id_rsa
```
Ii dam permisiuni de citire si scriere pentru owner:
```
chmod -u+rw id_rsa
```
Ne conectam cu ssh la userul creat pe masina noastra virtuala (pe masina locala)
```
ssh <numeuser>@<ipVM> -i /home/<userulnostru>/id_rsa
```
Daca primim un warning legat de key (ca nu este protejata) putem folosi comanda:
```
chmod 000 id_rsa
```
Si incercam din nou sa ne conectam cu ssh la userul creat.

