---
title: "Ansible"
date: 2018-01-28T22:01:36+01:00
anchor: "ansible-ex-3"
weight: 135
---

{{% block note %}}

**WHAT IS ANSIBLE**

Ansible is an IT automation tool.
It can configure systems, deploy software, and orchestrate advanced IT tasks such as continuous deployments or zero downtime rolling updates.

Ansible’s main goals are simplicity and ease-of-use.
It also has a strong focus on security and reliability, featuring a minimum of moving parts and usage of OpenSSH for transport.

Ansible manages machines in an "agentless" manner.
This means that Ansible can orchestrate actions on remote servers without having to first install special client software on them (e.g. puppet agent).

Ansible configuration is declarative, all tasks are defined using YAML.
It ships with several hundred built-in modules that can be used to perform just about any infrastructure management task you can imagine in an idempotent fashion.

**EXERCISE**

This one is easy, just run vagrant up! You'll know you were successful if you can SSH into the virtual machine as yourself without any manual configuration. We automated all that work you did in the previous exercises using Ansible.

**LEARNING OBJECTIVES**

- What is Ansible?
- How is it different than other tools like Chef or Puppet?
- What is YAML?
- What is a Vagrant provisioner?

{{% /block %}}

```
cd /home/dana/ansible/ansible
```
Modificam users.yml:

```yaml
- hosts: all
  become: yes
  become_method: sudo
  gather_facts: no
 
  tasks:
    - name: Install Python
      raw: test -e /usr/bin/python || (apt -y update && apt  install -y python)

    - name: ensure local user has a matching account on the host
      user:
        state: 'present'
        name: 'dana'
        shell: '/bin/bash'
        home: '/home/dana/'
        groups: sudo

    - name: ensure local user's public key is on the host
      authorized_key:
        user: "dana"
        key: "{{ lookup('file', '/root/.ssh/id_rsa.pub') }}"
```

Editam Vagrantfile:
```ruby
Vagrant.configure('2') do |config|
  #config.vm.box = 'centos/7'
  config.vm.box = 'generic/ubuntu1604'
  config.vm.provider :libvirt do |ans|
	ans.memory = "1024"
	ans.cpus = 1
  end
  config.vm.hostname = 'Ansible'
  config.vm.network :private_network, ip: '10.10.10.10'
  config.vm.provision 'ansible' do |ansible|
    ansible.playbook = 'users.yml'
  end
end
```

Instalam ansible
```
yum install -y ansible
```

Inainte de a incerca din nou, trebuie sa distrugem masina virtuala (doar pe asta!)
```
vagrant destroy default
```

Setam cheia privata:
```
ssh-keygen
```

Ne conectam prin comanda:
```
ssh vagrant@10.10.10.10
```


