---
title: "User Management"
date: 2018-01-28T22:01:36+01:00
anchor: "ansible-ex-5"
weight: 145
---

{{% block note %}}


**USER MANAGEMENT**

In a previous exercise we learned how to manage user accounts on a Linux machine using the command adduser.
We also experienced the joy of manually creating, managing the permissions for, and populating your ~/.ssh directory with an authorized_keys file.
While this approach to user management does work, it's tedious and prone to human error.

Ansible's user and authorized_key modules can help us to streamline and automate these tasks in an idempotent way.
It's a good idea to read through the documentation for each new module before you start using it.

**EXERCISE**

Use Ansible to add your user and the workshop user to the Vagrant box.
This exercise comes with a Vagrant file, and a boilerplate playbook with commented sections to help get you started.

You'll know you're done after you bring your Vagrant box up and can run the following commands without errors

```
ansible-playbook \
  -u vagrant \
  --private-key .vagrant/machines/default/virtualbox/private_key \
  -i 10.10.10.10, \
  playbook.yml
ssh 10.10.10.10
ssh -i ./workshop.pem workshop@10.10.10.10
```

If you encounter errors while running your playbook, you may have to run vagrant destroy && vagrant up to ensure your server is in a clean state.
Ask an instructor if you're not sure what an error is reporting.

**LEARNING OBJECTIVES**

- Can you identify the pieces that make up an Ansible playbook?
- How do you run Ansible against a remote server?
- How do you specify a user should be present using Ansible?
- How do you specify a private key should be present using Ansible?

{{% /block %}}



Va trebui sa modificam vagrantfile-ul astfel:

```ruby
Vagrant.configure('2') do |config|
  #config.vm.box = 'centos/7'
  config.vm.box = 'generic/ubuntu1604'
  config.vm.provider :libvirt do |ans|
        ans.memory = "1024"
        ans.cpus = 1
  end
  config.vm.hostname = 'Newans'
  config.vm.network :private_network, ip: '10.10.10.10'
end
```

Modificam playbook.yml:

```
- hosts: all
  become: yes
  become_method: sudo
  gather_facts: no
  tasks:
    - name: Install Python
      raw: test -e /usr/bin/python || (apt -y update && apt  install -y python)

    - name: ensure workshop user is on the box
      user:
	state: present
        name: dana
        shell: /bin/bash
        groups: sudo
        home: /home/dana

    - name: ensure my user’s public key is present in authorized_keys
      authorized_key:
        user: dana
        key: "{{ lookup('file', '/home/cata/learnansible/user-management/workshop.pub
        #key: ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC3DmXNR1rP+CGfMmwcowd4wN9uf6lKaN++9SyowsOmVQy
Y+x1jlka4rFUxljDrbJLyTmmdwH4fcOs/6ixZlMnNkbYcC48F8YrHWZ6lcheak52q365NRViooG+LuVZU81DOv/+roY0eTBTs6d
/mlRC8Us11kpKrtWi7zvFiv7Ld25Uo5yMPOxvDigJzrO0byVefq001mx5EEfDn9uH7nWU/e3wOIDls5kYtEWuI1QHWyOrbLe8
O+YiHznBjWa2r6dCobr8KfyfwBuHy4PxS4f17GJ9kGQXWOrVOjMJiblkHndQ5dMn8hQAt6Vir0EJL3XFE0xox9oqxV/LCH9lHc6mj workshop

        state: present
```

Daca nu ne va merge cheia de mai sus, vom copia la key continutul fisierului workshop.


Pornim serverul:

```
vagrant up --provider=libvirt
```

Acum vom rula playbook-ul:
```
ansible-playbook -u vagrant --private-key /home/cata/learnansible/user-management/.vagrant/machines/default/libvirt/private_key -i 10.10.10.10, playbook.yml
```
