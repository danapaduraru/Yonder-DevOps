---
title: "Variables, loops and filters"
date: 2018-01-28T22:01:36+01:00
anchor: "ansible-ex-6"
weight: 150
---

{{% block note %}}

**VARIABLES, LOOPS, AND FILTERS**

Just because Ansible is declarative doesn't mean it has to be verbose.
During the last exercise you may have wondered if there was a way to reduce some of the duplication in your tasks. 
Good news, there is!

By using mappings (hashes/dictionaries/objects), sequences (arrays/lists) and scalars (strings/numbers), we can set up data structures for Ansible to iterate over using with_ directives.


Also, Ansible leverages the popular python templating engine Jinja2, exposing many filters that allow complex transformations to be applied to your variables.

**VARIABLES**

In Ansible, there are several valid places to specify variables.
For this exercise we're going to focus on variables registered directly on tasks, and at the top of the playbook using the vars: parameter, like so:

```
- hosts: all
  become: yes
  become_method: sudo
  vars:
    some_variable: some value
```

If you're not sure how to define more complex data structures like dictionaries and lists, the Ansible docs provide a helpful YAML syntax overview.

**LOOPS**

Rather than repeating task definitions in your playbook, you can define a single entry that will run multiple times.
The most basic form of looping uses the with_items directive.

For example, this:

```
- name: add user testuser1
  user:
    name: testuser1
    state: present
    groups: wheel
- name: add user testuser2
  user:
    name: testuser2
    state: present
    groups: wheel
...can be equally defined like this:

- name: add several users
  user:
    name: "{{ item }}"
    state: present
    groups: sudo
  with_items:
     - testuser1
     - testuser2
...or this:

- hosts: all
  become: yes
  become_method: sudo
  vars:
    users:
      - testuser1
      - testuser2
  tasks:
    - name: add several users
      user:
        name: "{{ item }}"
        state: present
        groups: sudo
      with_items: "{{users}}"
```

For more complex data structures, like a list of dictionaries, the item variable that is passed into the task will contain properties that can be accessed using dot notation:

```
- hosts: all
  become: yes
  become_method: sudo
  vars:
    users:
      - name: testuser1
      - name: testuser2
  tasks:
    - name: add several users
      user:
        name: "{{ item.name }}"
        state: present
        groups: sudo
      with_items: "{{ users }}"
```

In addition to with_items, Ansible can loop on parallel sets of data using with_together, nested sets of data using with_subelements, file patterns using with_fileglob, dictionaries using with_dict and much more.

Read the Ansible docs for more looping options.

**EXERCISE**

In this exercise we'll be refactoring our work from the user-management exercise to DRY up the playbook by defining a user's list.

We'll then iterate over it using the with_items directive.
You'll know you've succeed when you're able to run the following commands without error:

```
ansible-playbook \
  -u vagrant \
  --private-key .vagrant/machines/default/virtualbox/private_key \
  -i 10.10.10.10, \
  playbook.yml
ssh 10.10.10.10
ssh -i ./workshop.pem workshop@10.10.10.10
```

Your playbook should only utilize the user and authorized_key modules once.

Once you've succeeded, ask yourself whether your solution is as robust as it could be.
Does it allow multiple public keys per user?
What about specifying the shell they prefer?
Are there filters that might help provide sensible default values, allowing properties in the user listing to be optional?

**LEARNING OBJECTIVES**

- Where are some places variables can be registered?
- How are variables referenced?
- How do you loop over an list or dictionary in Ansible?
- What are filters used for?
- What other looping constructs does Ansible support?
- How might you specify multiple public keys with a single invocation of the authorized_key module?

{{% /block %}}


Modificam Vagrantfile:

```ruby
Vagrant.configure('2') do |config|
  #config.vm.box = 'centos/7'
  config.vm.box = 'generic/ubuntu1604'
  config.vm.provider :libvirt do |ans|
        ans.memory = "1024"
        ans.cpus = 1
  end
  config.vm.hostname = 'Newans'
  config.vm.network :private_network, ip: '10.10.10.10'
end
```

Modificam playbook.yml:

```yml
- hosts: all
  become: yes
  become_method: sudo
  gather_facts: no
  vars:
    users:
      - name: dana
        state: present
        public_keys:
          - "{{ lookup('file', '/root/.ssh/id_rsa.pub') }}"
      - name: workshop
        state: present
        public_keys:
          - ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC3DmXNR1rP+CGfMmwcowd4wN9uf6lKaN++9SyowsOmVQyY+x1jlka4rFUxljDrbJLyTmmdwH4fcOs/6ixZlMnNkbYcC48F8YrHWZ6lcheak52q365NRViooG+LuVZU81DOv/+roY0eTBTs6d/mlRC8Us11kpKrtWi7zvFiv7Ld25Uo5yMPOxvDigJzrO0byVefq001mx5EEfDn9uH7nWU/e3wOIDls5kYtEWuI1QHWyOrbLe8O+YiHznBjWa2r6dCobr8KfyfwBuHy4PxS4f17GJ9kGQXWOrVOjMJiblkHndQ5dMn8hQAt6Vir0EJL3XFE0xox9oqxV/LCH9lHc6mj workshop
  tasks:
    - name: Install Python
      raw: test -e /usr/bin/python || (apt -y update && apt  install -y python)

    - name: ensure users are synced
      user:
        name: "{{ item.name }}"
        state: "{{ item.state }}"
        shell: "{{ item.shell | default('/bin/bash') }}"
        groups: "{{ item.groups | default('sudo') }}"
        force: yes
      with_items: "{{ users }}"

    - name: ensure user public keys are synced
      authorized_key:
        user: "{{ item.name }}"
        key: "{{ item.public_keys | join('\n') }}"
        state: present
        exclusive: yes
      with_items: "{{ users }}"
      when: "{{item.state == 'present'}}"
```
Si incercam sa rulam comanda:

```
ansible-playbook \
  -u vagrant \
  --private-key /home/dana/ansible/variables-loops-and-filters/.vagrant/machines/default/libvirt/private_key \
  -i 10.10.10.10, \
  playbook.yml
```

Gasim locatia private-key-ului prin comanda:
```
vagrant ssh-config
```

Dupa, vom rula comanda:
```
ssh -i ./workshop.pem workshop@10.10.10.10
```

Daca nu merge din cauza permisiilor, vom rula comanda:
```
chmod 600 workshop.pem
```
si vom incerca din nou.
