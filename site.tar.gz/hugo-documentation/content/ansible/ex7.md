---
title: "Control-flow"
date: 2018-01-28T22:01:36+01:00
anchor: "ansible-ex-7"
weight: 155
---

{{% block note %}}

**CONTROL FLOW**

You've seen how Ansible's declarative style implements loops and runs commands, so it should come as no surprise that conditionals and includes are also possible.

**WHEN**

The when directive ensures a task only executes when the provided conditional evaluates to true.

```
tasks:
 - debug: var="You will always see me!"
   when: true

 - debug: var="You will never see me!"
   when: false
```

In more complex Ansible configurations when is frequently used to augment which tasks will execute based on the environment they are being run in.

For example, it is common to have a Vagrant development machine configured in a slightly different manner than a production server using the same playbook.

If you find yourself using the same when statement for multiple tasks, consider using a block.

**BLOCKS**

Blocks can extend a conditional around a series of tasks and can also abort execution if any of the tasks fails.

This is very similar to try/catch/finally in many programming languages.

```
- block:
    - debug: msg='i execute normally'
    - command: /bin/false
    - debug: msg='i never execute, because the previous task exits non-zero
  rescue:
    - debug: msg='I caught an error'
    - command: /bin/false
    - debug: msg='i also never execute, because the previous task exits non-zero
  always:
    - debug: msg='i always execute'
```

**INCLUDE**

Ansible also provides a means of including tasks that are defined in separate files using include.

Combining a when directive with include is effectively like putting the when statement at the bottom of each task.


Included files are not defined as a playbook, but instead as only a list of tasks.

You can think of it like cutting and pasting the tasks from one file into the source file at runtime.

The included tasks have access to the same context as the parent file.

While this is helpful for logical grouping of tasks into files, Ansible has a much more powerful primitive for dealing with groups of tasks called roles.

While roles won't be covered in this workshop the core concepts we have covered should provide a solid foundation for independent experimentation.

**EXERCISE**

In this exercise, the automated users integration is not present.
You'll need to run your playbook as the vagrant user.

```
ansible-playbook \
  -u vagrant \
  --private-key .vagrant/machines/default/virtualbox/private_key \
  -i 10.10.10.10, \
  playbook.yml
```

Run this multiple times to see how the output is different.

Also, try overriding the env variable at the command line when you run Ansible to see how it affects the output.

**LEARNING OBJECTIVES**

- What is when and how do you use it?
- How do you extend a conditional over multiple tasks without defining the when conditional multiple times.
- How do you use blocks?
- How do you include tasks from external files?
- How do you pass variables at the command line to override env?

{{% /block %}}


Modificam Vagrantfile:

```ruby
Vagrant.configure('2') do |config|
  #config.vm.box = 'centos/7'
  config.vm.box = 'generic/ubuntu1604'
  config.vm.provider :libvirt do |ans|
        ans.memory = "1024"
        ans.cpus = 1
  end
  config.vm.hostname = 'Newans'
  config.vm.network :private_network, ip: '10.10.10.10'
end
```

Modificam playbook.yml:

```yml

- hosts: all
  become: yes
  become_method: sudo
  gather_facts: no
  vars:
    env: development
    swap_file_path: /swap
    swap_file_size: 2GB
  tasks:
    - name: Install Python
      raw: test -e /usr/bin/python || (apt -y update && apt  install -y python)

    - block:

      - name: ensure local user has a matching account on the host
        user:
          state: present
          name: "{{ lookup('env', 'USER') }}"
          shell: /bin/bash
          groups: sudo
        register: user

      - name: ensure local user's public key is on the host
        authorized_key:
          user: "{{ lookup('env', 'USER') }}"
          key: "{{ lookup('file', '~/.ssh/id_rsa.pub') }}"

      - name: ensure sudo group can sudo without a password
        lineinfile:
          dest: /etc/sudoers
          state: present
          regexp: "^%sudo"
          line: "%sudo\tALL=(ALL:ALL) NOPASSWD:ALL"
          validate: "visudo -cf %s"

      - name: check if swap file exists
        stat:
          path: "{{swap_file_path}}"
        register: swap_file_check

      - include: swap.yml
        when: not swap_file_check.stat.exists

      when: env == 'development'

```

Grija la spatiere si tab-uri. De exemplu, tab-urile nu sunt acceptate in yml.

Vom scrie comanda:
```
vagrant up --provider=libvirt
```

Si dupa vom incerca comanda:
```
ansible-playbook \
  -u vagrant \
  --private-key .vagrant/machines/default/virtualbox/private_key \
  -i 10.10.10.10, \
  playbook.yml
```

Daca primim eroarea: UNREACHABLE! => {"changed": false, "msg": "Failed to connect to the host via ssh: no such
 identity: /home/dana/ansible/control-flow/.vagrant/machines/default/virtualbox/private_key: 
No such file or directory\r\nPermission denied (publickey,password).\r\n", "unreachable": true}

este deoarece path-ul catre private key nu este cel corect. Il putem afla folosind:
```
vagrant ssh-config
```

Incercam din nou:
```
ansible-playbook \
  -u vagrant \
  --private-key /home/dana/ansible/control-flow/.vagrant/machines/default/libvirt/private_key \
  -i 10.10.10.10, \
  playbook.yml
```
