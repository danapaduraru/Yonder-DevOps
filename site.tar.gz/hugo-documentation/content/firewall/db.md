---
title: "DB"
date: 2018-01-28T22:01:36+01:00
anchor: "firewall-db"
weight: 90
---
```
cd /etc/firewalld/zones
cp public.xml yonder.xml
nano yonder.xml
```

```xml
<?xml version="1.0" encoding="utf-8"?>
<zone>
  <short>Yonder</short>
  <description>For us only.</description>
  <service name="ssh"/>
  <service name="snmp"/>
  <service name="dhcp"/> 
  <service name="dhcpv6-client"/>
  <port protocol="tcp" port="5432"/>
</zone>
```

```
systemctl enable firewalld
systemctl start firewalld
firwall-cmd --set-default-zone yonder
firewall-cmd --list-all
```
