---
title: "Go-interns Service"
date: 2018-01-28T21:58:09+01:00
anchor: "go-interns-service"
weight: 65
---

Cream un serviciu de systemd pe web care sa fie folosit pentru oprirea si pornirea aplicatiei go-interns. 

Info: https://www.digitalocean.com/community/tutorials/understanding-systemd-units-and-unit-files

```bash
cd /etc/systemd/system
touch /etc/systemd/system/go-interns.service
chmod 664 /etc/systemd/system/go-interns.service
nano go-interns.service
```

```bash
#go-interns.service
[Unit]
Description = Go-Interns Start & Stop Application
After = network.target

[Service]
ExecStart = /home/vagrant/go-interns/main
KillMode = process
WorkingDirectory = /home/vagrant/go-interns
StandardOutput =syslog
StandardError =syslog
SyslogIdentifier =internslog

[Install]
WantedBy = multi-user.target
```

Verificam daca am modificat ok serviciul:

```bash
systemctl daemon-reload
systemctl start go-interns
systemctl status go-interns
```

Dorim ca log-ul sa se salveze intr-un log file:

```bash
cd /etc/rsyslog.d/
touch internslog.conf
nano internslog.conf
```
```bash
#internslog.conf
if $programname == internslog then /var/log/internslog.log
if $programname == internslog then ~
```
Pentru a ne asigura ca functioneaza:
```bash
getenforce 
setenforce 0
```

Verificam:
```bash
journalctl -u rsyslog
journalctl -u go-interns
```

```bash
systemctl restart go-interns
systemctl restart rsyslog
```
