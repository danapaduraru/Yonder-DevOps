---
title: "Introduction"
date: 2018-01-27T15:42:17+01:00
anchor: "introduction"
weight: 10
---

Site-ul este realizat folosind hugo si are ca scop prezentarea documentatiei referitoare la lucrurile pe care le-am facut in cadrul internshipului de DevOps.

{{% block note %}}
Vom aborda urmatoarele subiecte:  
1. Scriptul de bash care logheaza consumul de resurse de pe sistem.  
2. Vagrantfile-ul si mediul pe care il creaza.  
3. Configul de nginx, atat partea de site cat si partea de reverse proxy.  
4. Configul de postgresql.  
5. Instalarea si configurarea aplicatiei go-interns. Fisierul de servicii, logarea in fisier, impachetarea in RPM.  
6. Cum poate fi creata o pagina noua de documentatie pentru site-ul vostru
{{% /block %}}
