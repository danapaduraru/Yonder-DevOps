---
title: "Nagios"
date: 2018-01-28T22:01:36+01:00
anchor: "nagios"
weight: 270
---
NAGIOS

Nagios, now known as Nagios Core, is a free and open source computer-software application that monitors systems, 
networks and infrastructure.
Nagios offers monitoring and alerting services for servers, switches, applications and services.

**Installing and Configuration**

Perform these steps to install the pre-requisite packages.

```
yum install -y gcc glibc glibc-common wget unzip httpd php gd gd-devel perl postfix
```

Downloading the Source

```
cd /tmp
wget -O nagioscore.tar.gz https://github.com/NagiosEnterprises/nagioscore/archive/nagios-4.4.1.tar.gz
tar xzf nagioscore.tar.gz
```

Compile

```
cd /tmp/nagioscore-nagios-4.4.1/
./configure
make all
```

Create User And Group

This creates the nagios user and group. The apache user is also added to the nagios group.

```
make install-groups-users
usermod -a -G nagios apache
```

Install Binaries

This step installs the binary files, CGIs, and HTML files.

```
make install
```

Install Service / Daemon
This installs the service or daemon files and also configures them to start on boot. The Apache httpd service is also configured at this point.
 
===== CentOS 7.x | RHEL 7.x | Oracle Linux 7.x =====

```
make install-daemoninit
systemctl enable httpd.service
```

Install Command Mode

This installs and configures the external command file.
```
make install-commandmode
```

Install Configuration Files

This installs the *SAMPLE* configuration files. These are required as Nagios needs some configuration files to allow it to start.
```
make install-config
```

Install Apache Config Files

This installs the Apache web server configuration files. Also configure Apache settings if required.
```
make install-webconf
```

Configure Firewall

You need to allow port 80 inbound traffic on the local firewall so you can reach the Nagios Core web interface.

===== CentOS 7.x | RHEL 7.x | Oracle Linux 7.x =====

```
firewall-cmd --zone=public --add-port=80/tcp
firewall-cmd --zone=public --add-port=80/tcp --permanent
```

Create nagiosadmin User Account

You'll need to create an Apache user account to be able to log into Nagios.

The following command will create a user account called nagiosadmin and you will be prompted to provide a password for the account.
```
htpasswd -c /usr/local/nagios/etc/htpasswd.users nagiosadmin
```
Add a new password (mine is nagios)

Start Apache Web Server

===== CentOS 7.x | RHEL 7.x | Oracle Linux 7.x =====
```
systemctl start httpd.service
```

Start Service / Daemon

This command starts Nagios Core.
 

===== CentOS 7.x | RHEL 7.x | Oracle Linux 7.x =====
```
systemctl start nagios.service
```

Now you should be able to enter:
http://127.0.0.1/nagios/

This was just Nagios Core. We need to install the plugin as well.

**NAGIOS PLUGIN**

```
yum install -y gcc glibc glibc-common make gettext automake autoconf wget openssl-devel net-snmp net-snmp-utils epel-release
yum install -y perl-Net-SNMP
```

```
cd /tmp
wget --no-check-certificate -O nagios-plugins.tar.gz https://github.com/nagios-plugins/nagios-plugins/archive/release-2.2.1.tar.gz
tar zxf nagios-plugins.tar.gz
```

```
cd /tmp/nagios-plugins-release-2.2.1/
./tools/setup
./configure
make
make install
```


