---
title: "SNMP"
date: 2018-01-28T22:01:36+01:00
anchor: "snmp"
weight: 275
---

SNMP

**Simple Network Management Protocol (SNMP)** is a popular protocol for network management.

 It is used for collecting information from, and configuring, network devices, such as servers, printers, hubs, switches, and routers on an Internet Protocol (IP) network.

Instalam si pe proxy SNMP:

```
yum -y install net-snmp net-snmp-utils
systemctl start snmpd
```

Modificam /etc/snmpd.conf cu ceva mai light:

```
# Mappings between community strings and security names
#           security name   source mask     community id

com2sec LocalNet    	127.0.0.1            public
com2sec ServerNet       192.168.4.0/24       public


# Mappings between security names and group names
#       group name      security model      security name

group   ROGroup     		v1           	ServerNet
group   ROGroup    		v2c           	ServerNet
group   ROGroup			v3		roadmin


# View definitions
#       view name       included/excluded   		subtree
#view    systemview    		included   			.1.3.6.1.2.1.1
#view    systemview    		included   			.1.3.6.1.2.1.25.1.1
view     all             	included                        .1  80

# Access control directives
#       group name      context     model   	level   	match       	read            write       	notif


access  ROGroup		""	    v1     	noauth		exact		all		none		none
access  ROGroup		""	    v2c		noauth		exact		all		none		none
access  ROGroup		""	    v3     	priv    	exact       	all             none        	none

dontLogTCPWrappersConnects yes

syslocation  "RO, Iasi DataCenter"
syscontact  

rouser roadmin
# Allow Systems Management Data Engine SNMP to connect to snmpd using SMUX
smuxpeer .1.3.6.1.4.1.674.10892.1
```

```
systemctl restart snmpd.conf
```

Pe localhost, am modificat in /usr/local/nagios fisierele, inlocuindu-le cu cele de pe linkul:
http://nagios.manubulon.com/nagios-snmp-plugins.1.1.1.tgz

Acum vom incerca sa rulam un program:
```
perl check_snmp_load.pl -C public -2 -H 10.143.20.2 -w 80 -c 90
```

Pentru mai multe informatii putem folosi comanda:
```
perl check_snmp_load.pl -h
```

