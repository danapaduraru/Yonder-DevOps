---
title: "Logging"
date: 2018-01-28T22:01:36+01:00
anchor: "logging"
weight: 250
---

{{% block note %}}

**RSYSLOG**

Tasks:

- install - have a running rsyslog service 
- custom config  - all logs stored on the srver have a custom name
- centralized log server - all machines are sending logs to a central server
- custom name for log received from remote hosts - on the central server logs are stored in a folder with the name of the host, logs name must be like this: service_name.date.log
- logrotate an archive old logs - configure logroatte on the central server to archive logs every day.
- configure slave server - have a second server with rsyslog for storing logs when the master server is down
- send logs to second server if primary is down - poweroff master server and test if logs are stored on the slave

{{% /block %}}


Logurile se gasesc in /var/log.
Configurarile se gasesc in /etc.

De exemplu, putem modifica rsyslog.conf din /etc pentru a primi mesajele de log intr-un folder custom plasat oriunde.

```
#*.info;mail.none;authpriv.none;cron.none                /var/log/messages
*.info;mail.none;authpriv.none;cron.none 	        /home/vagrant/rsyslog-messages
```

Vom folosi comanda:
```
systemctl restart rsyslog
```

Si daca facem de exemplu comenzile
```
su - 
su vagrant
```
logul va aparea in noul folder creat.


Deocamdata este posibil sa nu apara, deoarece nu are permisiile de care are nevoie. SElinux il blocheaza.
Vom decomenta linia pe care am comentat-o si vom duplica logul pentru a verifica daca apare in /var/log.
Daca apare si totul este ok, inseamna ca problema este de la SElinux.
Cu comanda
```
setatus
```
aflam "current mode" pentru SElinux. Daca acesta este "enforcing", vom folosi comanda:
```
setenforce 0
```
si va deveni "permissive", ceea ce inseamna ca folderul nostru va putea fi creat si folosit pentru loguri.
