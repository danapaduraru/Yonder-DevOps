---
title: "Centralized Rsyslog Server"
date: 2018-01-28T22:01:36+01:00
anchor: "centralized-rsyslog-server"
weight: 255
---

Install rsyslog package if it is not installed already.

```
yum install rsyslog

vi /etc/rsyslog.conf
```

Find and uncomment the following to make your server to listen on the udp and tcp ports.
```
[...]
$ModLoad imudp
$UDPServerRun 514

[...]
$ModLoad imtcp
$InputTCPServerRun 514
[...]
```

Allow Rsyslog default port 514 on your firewall/router.
 The following commands will open this port via firewalld.
```
firewall-cmd --permanent --add-port=514/udp
firewall-cmd --permanent --add-port=514/tcp
```
Restart firewalld service to take effect the changes.
```
firewall-cmd --reload
```
Finally, enable and start rsyslog service:
```
systemctl enable rsyslog
systemctl start rsyslog
systemctl status rsyslog
```

If you see an output something lik below, congrats! Rsyslog server is up and working!
```
● rsyslog.service - System Logging Service
 Loaded: loaded (/usr/lib/systemd/system/rsyslog.service; enabled; vendor preset: enabled)
 Active: active (running) since Thu 2017-03-23 16:30:11 IST; 17min ago
 Main PID: 2490 (rsyslogd)
 CGroup: /system.slice/rsyslog.service
 └─2490 /usr/sbin/rsyslogd -n

Mar 23 16:30:11 logserver.ostechnix.local systemd[1]: Starting System Logging...
Mar 23 16:30:11 logserver.ostechnix.local systemd[1]: Started System Logging ...
Hint: Some lines were ellipsized, use -l to show in full
```

You can check log details of the server itself using command:
```
tail -10 /var/log/messages
```
This command will display the last ten lines of your log messages.

**Client configuration**

Install rsyslog using command:
```
yum install rsyslog
vi /etc/rsyslog.conf
```

Under ##RULES## directive section, add the following line:

```
*.* @192.168.43.150:514
```
Or, just place this line at the end. This will log everything and send the log files to your Rsyslog server. You can also log particular items. Say for example, to log only cron stuffs, add the following line:
```
cron.* @192.168.43.150:514
```
To log all the mail messages, add:
```
mail.* @192.168.43.150:514
```
I want to log everything, so I added the following line.
```
*.* @192.168.43.150:514
```
You can also mention the FQDN of your Rsyslog server instead of IP address.
For finding out your IP address:
```
ip a
```
Save and close the rsyslog config file.

Finally, enable and start rsyslog service:
```
systemctl enable rsyslog
systemctl start rsyslog
```

Run anything on your client system.

I am going to run this:
```
logger -i -t ostechnix "This is our first log test."
```

Now, go to the Rsyslog server machine and check if this log is found.
```
tail -f /var/log/messages
```

Now, you will the logs of your client systems from the server.


!! Daca inca nu functioneaza:

- stop firewalld service

- setenforce 0

SAU

- intram in configuratia lui Selinux si modificam "current mode" in disabled.

Si incercam din nou.

Bonus command:
```
date
```
~~~~~~
Daca folosim centralizarea pe doua masini virtuale (adica de exemplu 
log-urile de pe proxy le punem si pe localhost si pe monitor) atunci 
cand una dintre masini va pica, vom avea log-urile pe cealalta. Safe <3
