---
title: "Rotate logs"
date: 2018-01-28T22:01:36+01:00
anchor: "rotatelog"
weight: 265
---

**Rotate Log**

Creati un config de logrotate pentru logurile noastre, care sa arhiveze la sfarsitul zilei fisierele.

Editam logrotate.conf (/etc/logrotate.conf):

```
/home/dana/template-logs/*/* {
        rotate 5
        missingok
        compress
        daily
}

# Punem doua stelute pentru ca avem niste subfoldere in template-logs 
# si vrem sa folosim rotatelog pentru toate fisierele de log din folderul template-logs.
# ia toate fisierele din home/dana/template-logs (*), le arhiveaza (compress)
# daca nu exista e ok (missingok), zilnic(daily), dupa ce face asta de 5 ori
# va sterge.
```

Pentru a verifica vom da un rotatelog fortat:

```
logrotate -f /etc/logrotate.conf
```

Si intram in folderul nostru (/home/dana/template-logs) pentru a verifica daca apar arhivele.

