---
title: "Templates in rsyslog.conf"
date: 2018-01-28T22:01:36+01:00
anchor: "templates-rsyslog"
weight: 260
---
Templates in Rsyslog.conf

in localhost:

```
nano /etc/rsyslog.conf
```

Add the following after local7.*:

```
# template
$template mytemplate, "/home/dana/template-logs/%HOSTNAME%/messages.log"
*.info ?mytemplate

# template
$template securetemplate, "/home/dana/template-logs/%HOSTNAME%/secure.log"
authpriv.* ?securetemplate
```

Restart:
```
systemctl restart syslog
```
on both proxy and localhost. 

On proxy:
```
exit
sudo su -
```
in order to have some logs. 

Your logs should appear at /home/dana/template-logs/localhost and /home/dana/template-logs/proxy (secure.log and messages.log)
