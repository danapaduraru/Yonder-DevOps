---
title: "Vagrant"
date: 2018-01-28T21:48:57+01:00
anchor: "vagrant"
weight: 15
---

Pentru a crea un vagrant file, va fi nevoie sa instalam Vagrant si un provider (kvm/libvirt). 

Optional, putem instala Virtual Box Manager pentru a putea folosi libvirt (kvm va prelua VirtualBox by default)

Un exemplu de Vagrantfile putin mai complex, care creaza 2 masini virtuale gasiti aici: https://github.com/aso930/btw-linuxcloud/blob/master/vagrant/Vagrantfile

Care e structura unui Vagrantfile simplist:
```
Vagrant.configure("2") do |config|

    #Configuratia masinilor virtuale vine aici.
	
end
```
Pentru a seta ca vagrant folder directorul curent:
```
vagrant init centos7
```
Comanda urmatoare creeaza si configureaza masinile virtuale in concordanta cu Vagrant file-ul facut de noi:
```
vagrant up
```
Pentru a afla informatii referitoare la configuratia ssh:
```
vagrant ssh-config
```
Pentru a opri masinile virtuale:
```
vagrant halt
```
SAU
```
vagrant destroy nume_masina 
```
(va distruge de tot masina virtuala)

Pentru a putea porni vagrant folosind un anumit provider:
```
vagrant up --provider=kvm
```

Vom folosi in continuare providerul libvirt, deci il vom instala mai intai:
```
sudo yum plugin install vagrant-libvirt
sudo systemctl enable libvirtd
sudo systemctl start libvirtd
vagrant up --provider=libvirt
```
