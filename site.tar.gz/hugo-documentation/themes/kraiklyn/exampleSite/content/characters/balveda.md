---
title: "Balveda"
date: 2018-01-28T21:55:52+01:00
anchor: "balveda"
weight: 40
---

Juboal-Rabaroansa Perosteck Alseyn Balveda dam T'seif, usually referred to as Perosteck Balveda, is an operative of the Culture assigned to track and apprehend [Bora Horza Gobuchul]({{% anchor "characters/bora.md" %}}). She works for the Special Circumstances branch of Contact, and despite being ambivalent about the methods they use, deeply believes in their objectives.
