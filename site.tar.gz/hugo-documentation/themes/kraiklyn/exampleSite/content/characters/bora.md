---
title: "Bora"
date: 2018-01-28T21:54:02+01:00
anchor: "bora"
weight: 30
---

**Bora Horza Gobuchul** is a [Changer](https://en.wikipedia.org/wiki/List_of_civilisations_in_the_Culture_series) and an operative of the Idiran Empire. Horza was one of a party of Changers allowed on Schar's World, and for that reason is tasked by the Idirans with retrieving a Mind that had crashed to the planet. Horza is humanoid, but committed to the Idirans because he despises the Culture for its dependence on machines and what he perceives to be spiritual emptiness.
