---
title: "Kraiklyn"
date: 2018-01-28T21:57:07+01:00
anchor: "kraiklyn"
weight: 50
---

Kraiklyn is the captain of the Clear Air Turbulence.
