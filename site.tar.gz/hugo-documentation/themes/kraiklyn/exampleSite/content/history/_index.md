---
title: "History"
date: 2018-01-28T21:58:09+01:00
anchor: "history"
weight: 60
---

Consider Phlebas, like most of Banks's early SF output, was a rewritten version of an earlier book, as he explained in a 1994 interview:

>Phlebas was an old one too; it was written just after The Wasp Factory, in 1984. I've found that rewriting an old book took much more effort than writing one from scratch, but I had to go back to do right by these things. Now I can go on and start completely new stuff.
